from pydantic import BaseModel

class DashboardTile(BaseModel):
    # implement dashboard tile schema
    pass